This example creates an SDL window and renderer, and then draws some lines,
rectangles and points to it every frame.

This is just a quick overview of simple drawing primitives; futher examples
will explore them in more detail.


